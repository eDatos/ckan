"""Tests for plugin.py."""
import ckanext.istac_theme.plugin as plugin

def test_plugin():
    pass